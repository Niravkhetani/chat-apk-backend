const ResetPasswordDefault = "RazgovorChat";

module.exports = {
  ResetPasswordDefault,
};
