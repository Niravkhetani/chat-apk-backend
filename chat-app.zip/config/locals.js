var fs = require('fs');

module.exports = {

    ssl : {
    //     key: fs.readFileSync('/etc/letsencrypt/live/arsell-staging.mylionsgroup.com/privkey.pem'),
    //    cert: fs.readFileSync('/etc/letsencrypt/live/arsell-staging.mylionsgroup.com/fullchain.pem')
    }

};


